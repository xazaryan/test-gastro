<template>
    <v-app class="gestro-app" id="gestroApp">
        <div class="content-block">
            <router-view/>
        </div>
    </v-app>
</template>

<script>
export default {
    name: "App",
    data: () => ({}),
    created() {
    },
    mounted() {
    },
    methods: {},
    computed: {},
}
</script>